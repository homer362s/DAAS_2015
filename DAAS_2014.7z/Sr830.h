extern void sr830_Init (void);
