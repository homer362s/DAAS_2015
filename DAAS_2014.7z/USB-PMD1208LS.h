extern void usb1208ls_Init(void);
