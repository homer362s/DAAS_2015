extern void k2400_Init (void);
