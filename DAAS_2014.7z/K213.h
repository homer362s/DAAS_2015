extern void k213_Init (void);
