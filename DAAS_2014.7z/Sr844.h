extern void sr844_Init (void);
