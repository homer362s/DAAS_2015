extern void boards_DigitalSourceInit (portPtr port);
extern int boards_DigitalSourceControlCallback (int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
