extern void LS335_Init(void);
