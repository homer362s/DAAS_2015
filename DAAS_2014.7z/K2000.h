extern void k2000_Init (void);
