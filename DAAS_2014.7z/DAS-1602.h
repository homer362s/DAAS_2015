extern void das1602_Init(void);
