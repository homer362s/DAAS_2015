extern void curveop_Init (void);
