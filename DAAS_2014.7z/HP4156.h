extern void hp4156_Init(void);
