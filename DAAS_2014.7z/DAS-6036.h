extern void das6036_Init(void);
