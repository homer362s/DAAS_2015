extern void k236_Init (void);
