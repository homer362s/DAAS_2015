extern void changen_Init (void);
