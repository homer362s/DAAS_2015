extern void aspa_Init(void);
