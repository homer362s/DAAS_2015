extern void hp33120a_Init(void);
