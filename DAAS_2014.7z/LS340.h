extern void LS340_Init(void);
