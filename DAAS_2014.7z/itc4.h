extern void itc4_Init(void);
