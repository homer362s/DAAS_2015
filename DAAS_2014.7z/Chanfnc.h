extern void chanfunc_Init (void);
