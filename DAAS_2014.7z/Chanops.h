extern void chanops_Init (void);
